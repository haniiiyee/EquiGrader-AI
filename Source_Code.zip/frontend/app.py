# frontend/app.py
import streamlit as st
import requests
import time
from streamlit_mic_recorder import mic_recorder 

BACKEND_URL = "http://127.0.0.1:8000"

st.set_page_config(page_title="AI Smart Interviewer", page_icon="🤖", layout="wide")

# --- Session State ---
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []
if 'session_started' not in st.session_state:
    st.session_state.session_started = False
if 'current_question' not in st.session_state:
    st.session_state.current_question = None
if 'evaluation_result' not in st.session_state:
    st.session_state.evaluation_result = None

# --- 1. Login System (Required for UiPath) ---
def login_page():
    st.title("🔒 Login to Smart Interviewer")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    
    if st.button("Login"):
        # Simple hardcoded check for demonstration
        if username == "student" and password == "pass123":
            st.session_state.logged_in = True
            st.success("Login Successful!")
            time.sleep(1)
            st.rerun()
        else:
            st.error("Invalid Credentials (Try: student / pass123)")

# --- 2. Main Interview App ---
def main_app():
    # --- Sidebar Chatbot (Required for Requirement 1) ---
    with st.sidebar:
        st.title("🤖 AI Assistant")
        st.markdown("Ask me anything about ECE or how to use this app!")
        
        # Display chat history
        for msg in st.session_state.chat_history:
            with st.chat_message(msg["role"]):
                st.write(msg["content"])

        # Chat input
        if user_input := st.chat_input("Ask a question..."):
            # Add user message to history
            st.session_state.chat_history.append({"role": "user", "content": user_input})
            with st.chat_message("user"):
                st.write(user_input)
            
            # Get AI Response
            with st.spinner("Thinking..."):
                try:
                    resp = requests.post(f"{BACKEND_URL}/chat", json={"message": user_input})
                    if resp.status_code == 200:
                        ai_reply = resp.json()["response"]
                        st.session_state.chat_history.append({"role": "assistant", "content": ai_reply})
                        with st.chat_message("assistant"):
                            st.write(ai_reply)
                    else:
                        st.error("Bot failed to respond.")
                except:
                    st.error("Connection Error.")

    # --- Main Content ---
    st.title("🤖 AI Smart Interviewer")
    
    # Topic Selection
    st.header("1. Start Your Interview")
    TOPIC_MAP = {"Electronics (ECE)": "ECE", "Aptitude": "Aptitude"}
    selected_display = st.selectbox("Choose Topic:", list(TOPIC_MAP.keys()))
    
    if st.button("Start New Interview Session"):
        api_topic = TOPIC_MAP[selected_display]
        try:
            resp = requests.get(f"{BACKEND_URL}/get_question?topic={api_topic}")
            if resp.status_code == 200:
                st.session_state.current_question = resp.json()
                st.session_state.session_started = True
                st.session_state.evaluation_result = None
                st.rerun()
        except:
            st.error("Backend not running.")

    if st.session_state.session_started and st.session_state.current_question:
        q_data = st.session_state.current_question
        st.header("2. Question")
        st.info(q_data['question'])
        
        # Preparation Timer
        if 'prep_done' not in st.session_state:
            with st.empty():
                for i in range(5, 0, -1): # Shortened to 5s for easier testing
                    st.warning(f"⚠️ Preparing... Recording enables in {i}s")
                    time.sleep(1)
                st.success("Go!")
            st.session_state.prep_done = True

        st.header("3. Answer")
        tab1, tab2 = st.tabs(["💬 Text", "🎤 Audio"])
        
        with tab1:
            txt_ans = st.text_area("Type Answer")
            if st.button("Submit Text"):
                with st.spinner("Evaluating..."):
                    resp = requests.post(f"{BACKEND_URL}/evaluate_answer", json={"question_id": q_data["id"], "answer_text": txt_ans})
                    st.session_state.evaluation_result = resp.json()
                    st.rerun()
        
        with tab2:
            audio = mic_recorder(start_prompt="Record 🔴", stop_prompt="Stop ⏹️", key="recorder")
            if audio and st.button("Submit Audio"):
                with st.spinner("Transcribing & Evaluating..."):
                    files = {'question_id': (None, q_data['id']), 'audio_file': ('a.wav', audio['bytes'], 'audio/wav')}
                    resp = requests.post(f"{BACKEND_URL}/evaluate_audio", files=files)
                    st.session_state.evaluation_result = resp.json()
                    st.rerun()

    if st.session_state.evaluation_result:
        res = st.session_state.evaluation_result
        st.header("4. Result")
        st.subheader(f"Score: {res['overall_score']}%")
        st.write(res['final_summary'])

# --- App Logic ---
if not st.session_state.logged_in:
    login_page()
else:
    main_app()