# backend/main.py

import json         
import random       
import uvicorn      
import ollama       
import whisper      
import shutil       
from fastapi import FastAPI, HTTPException, Query, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel  

app = FastAPI(title="AI Smart Interviewing System API", version="2.0.0")

origins = ["http://localhost", "http://localhost:8501"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Global Data ---
def load_question_bank():
    try:
        with open("questions.json", "r") as f:
            print("INFO:     Loading question bank...")
            return json.load(f)
    except:
        return [] 

QUESTION_BANK = load_question_bank()
WHISPER_MODEL = whisper.load_model("base") 
print("INFO:     Whisper 'base' model loaded.")

# --- Data Models ---
class AnswerRequest(BaseModel):
    question_id: str
    answer_text: str

class ChatRequest(BaseModel):
    message: str

# --- Helper Functions ---
def get_question_by_id(question_id: str):
    for question in QUESTION_BANK:
        if question["id"] == question_id:
            return question
    return None 

def create_evaluation_prompt(question: str, rubric: list, answer: str) -> str:
    rubric_str = ""
    for i, item in enumerate(rubric):
        rubric_str += f"{i+1}. {item['point']}: {item['expected_answer']}\n"

    return f"""
    You are an expert technical interviewer. Evaluate this answer based ONLY on the rubric.
    Question: "{question}"
    Rubric: {rubric_str}
    Candidate Answer: "{answer}"
    
    Respond ONLY in JSON:
    {{
      "rubric_evaluation": [
        {{ "point": "...", "met": true/false, "feedback": "..." }}
      ],
      "overall_score": <number>,
      "final_summary": "..."
    }}
    """

async def perform_evaluation(question_id: str, answer_text: str):
    question_data = get_question_by_id(question_id)
    if not question_data:
        raise HTTPException(status_code=404, detail="Question not found.")
    
    prompt = create_evaluation_prompt(question_data["question"], question_data["scoring_rubric"], answer_text)
    
    try:
        response = ollama.chat(model='phi3', messages=[{'role': 'user', 'content': prompt}], format='json')
        return json.loads(response['message']['content'])
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def transcribe_audio_to_text(audio_file_path: str) -> str:
    result = WHISPER_MODEL.transcribe(audio_file_path, fp16=False)
    return result["text"]

# --- Endpoints ---

@app.get("/get_question")
def get_question(topic: str = Query(...)):
    topic_questions = [q for q in QUESTION_BANK if topic.lower() in q["topic"].lower()]
    if not topic_questions:
        raise HTTPException(status_code=404, detail="No questions found.")
    return random.choice(topic_questions)

@app.post("/evaluate_answer")
async def evaluate_answer(request: AnswerRequest):
    return await perform_evaluation(request.question_id, request.answer_text)

@app.post("/evaluate_audio")
async def evaluate_audio(question_id: str = File(...), audio_file: UploadFile = File(...)):
    temp_path = f"temp_{audio_file.filename}"
    with open(temp_path, "wb") as buffer:
        shutil.copyfileobj(audio_file.file, buffer)
    try:
        text = transcribe_audio_to_text(temp_path)
        result = await perform_evaluation(question_id, text)
        result["transcribed_text"] = text
        return result
    finally:
        import os
        if os.path.exists(temp_path): os.remove(temp_path)

# --- NEW: General Chatbot Endpoint ---
@app.post("/chat")
async def chat_bot(request: ChatRequest):
    """
    Context-aware chatbot that helps the user with the platform or ECE concepts.
    """
    system_context = """
    You are the AI Assistant for the 'Smart Interviewer' platform. 
    Your job is to help students prepare for interviews in ECE and Aptitude.
    If they ask about the app, explain that it generates questions and grades answers.
    If they ask technical questions, provide brief, clear explanations.
    Keep answers concise and helpful.
    """
    
    try:
        response = ollama.chat(
            model='phi3',
            messages=[
                {'role': 'system', 'content': system_context},
                {'role': 'user', 'content': request.message}
            ]
        )
        return {"response": response['message']['content']}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)