AI Smart Interviewer - Execution Instructions
---------------------------------------------
1. Install dependencies: pip install -r requirements.txt
2. Run Backend: 
   cd backend
   python main.py
3. Run Frontend (in a new terminal):
   cd frontend
   streamlit run app.py
4. Login Credentials: student / pass123